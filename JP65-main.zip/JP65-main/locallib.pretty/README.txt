These footprints were created by amtra5.
Please give proper credits when using these footprints.

Logic lib created by _spindle.
Please give proper credits when using the library.