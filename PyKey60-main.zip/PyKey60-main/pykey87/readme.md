# PyKey87

### What is PyKey87?


![PyKey87](./images/PyKey87.PNG)

### How do I build it?

You don't need many tools to build it!  
* Press the switches through the top plate
* Align the key switch pins with their sockets and press them in, 
* Install the keycaps
* Install the adhesive rubber bump ons as feet.